﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace CH8_SelfTest
{
    class Program
    {
        static void Main(string[] args)
        {
            // כתוב קטע קוד שידפיס את כל המספרים הדו-סיפרתיים
            Console.WriteLine("\nAll 2-digit numbers in ascending order");


            // כתוב קטע קוד שידפיס את כל המספרים התלת-ספרתיים בסדר הפוך
            Console.WriteLine("\nAll 3-digit numbers in descending order");



            // כתוב קטע קוד שידפיס את כל אותיות ה-א"ב הקטנות באנגלית
            Console.WriteLine("\nAll small abc letters");


            // כתוב קטע קוד שידפיס את כל המספרים הזוגיים בין 0 ל-50 (כולל)
            Console.WriteLine("\nAll even numbers between 0 and 50");


            // כתוב קטע קוד שידפיס את כל המספרים האי-זוגיים בין 0ל-50 (כולל)
            Console.WriteLine("\nAll odd numbers between 0 and 50");


            // קלוט מספר חיובי שלם בין 1 ל-100 והדפס את כל המחלקים של המספר
            int num;
            num = int.Parse(Console.ReadLine());
            Console.WriteLine("\nAll dividers of " +num);


            // הדפס את כל המספרים בין 10 ל-100 שמופיעה בהם הספרה 7
            Console.WriteLine("\nAll numbers between 10 to 100 with digit 7");


            // הדפס את כל המספרים הדו-סיפרתיים שמתחלקים ב-3
            Console.WriteLine("\nAll 2-digit numbers that are divided by 3");


            // הדפס את כל המספרים התלת סיפרתיים שסכום ספרותיהם הוא 12
            Console.WriteLine("\nAll 3-digit numbers whose digits' sum = 12");


            // a,c,e,g,i..,y הדפס את את סדרת האותיות הבאה: 
            Console.WriteLine("\nAll small abc letters in steps of two ");



        
        }
    }
}
